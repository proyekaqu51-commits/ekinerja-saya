import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Plus,
  Sparkles,
  Printer,
  Edit2,
  Trash2,
  Eye,
  X,
  Search,
  Filter,
  CheckCircle2,
  BookOpen,
  Calendar,
  Layers,
  GraduationCap,
  HeartHandshake,
  Download,
  AlertCircle,
  FileText,
  ExternalLink,
  ArrowLeft,
  Upload,
  FolderOpen
} from 'lucide-react';
import { TeachingDocument, TeachingDocType, TeachingReferenceDoc } from '../../types';
import { StorageService } from '../../services/storageService';
import { AiTeachingDocService } from '../../services/aiTeachingDocService';
import { openDocumentInNewTab, REGULASI_RESMI_BKPDM } from '../../utils/printDocumentHelper';
import { ManualTeachingDocModal } from './ManualTeachingDocModal';
import { UploadReferenceDocModal } from './UploadReferenceDocModal';

interface TeachingDocumentsViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

const DOC_TYPES: { id: TeachingDocType; label: string; short: string; desc: string; color: string }[] = [
  { id: 'cp_atp', label: 'CP / ATP', short: 'CP/ATP', desc: 'Capaian & Alur Tujuan Pembelajaran', color: 'from-blue-500 to-indigo-600' },
  { id: 'prota', label: 'Program Tahunan (Prota)', short: 'Prota', desc: 'Distribusi Alokasi Jam 1 Tahun Ajaran', color: 'from-emerald-500 to-teal-600' },
  { id: 'promes', label: 'Program Semester (Promes)', short: 'Promes', desc: 'Rincian Pekan Efektif Ganjil / Genap', color: 'from-cyan-500 to-blue-600' },
  { id: 'kktp', label: 'KKTP', short: 'KKTP', desc: 'Kriteria Ketercapaian Tujuan Pembelajaran', color: 'from-amber-500 to-orange-600' },
  { id: 'modul_ajar', label: 'Modul Ajar (RPP)', short: 'Modul Ajar', desc: 'RPP Merdeka Berdiferensiasi & KBC', color: 'from-purple-500 to-violet-600' },
  { id: 'lkpd', label: 'LKPD', short: 'LKPD', desc: 'Lembar Kerja Peserta Didik Ceria', color: 'from-rose-500 to-pink-600' },
  { id: 'lainnya', label: 'Perangkat Ajar Lainnya', short: 'Lainnya', desc: 'Silabus, Kisi-Kisi, Remedial & Lainnya', color: 'from-teal-500 to-emerald-600' }
];

export const TeachingDocumentsView: React.FC<TeachingDocumentsViewProps> = ({ showToast }) => {
  const teacherProfile = StorageService.getTeacherProfile();
  const appSettings = StorageService.getAppSettings();

  const [documents, setDocuments] = useState<TeachingDocument[]>(StorageService.getTeachingDocs());
  const [selectedGrade, setSelectedGrade] = useState<string>('5');
  const [selectedDocType, setSelectedDocType] = useState<TeachingDocType | 'all'>('all');
  const [selectedSemester, setSelectedSemester] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals state
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiPreviewDoc, setAiPreviewDoc] = useState<TeachingDocument | null>(null);

  // Manual Input / Edit Modal state
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [editingDoc, setEditingDoc] = useState<TeachingDocument | null>(null);
  const [manualDefaultType, setManualDefaultType] = useState<TeachingDocType>('cp_atp');
  const [activeManualRefDoc, setActiveManualRefDoc] = useState<TeachingReferenceDoc | null>(null);

  // Reference / Acuan Docs state
  const [referenceDocs, setReferenceDocs] = useState<TeachingReferenceDoc[]>(StorageService.getTeachingRefDocs());
  const [isUploadRefModalOpen, setIsUploadRefModalOpen] = useState(false);
  const [selectedAiRefId, setSelectedAiRefId] = useState<string>('');

  // Detail Modal
  const [viewingDoc, setViewingDoc] = useState<TeachingDocument | null>(null);

  // Print Modal
  const [printDoc, setPrintDoc] = useState<TeachingDocument | null>(null);

  // Delete Target Modal
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; title: string } | null>(null);

  // AI Form state
  const [aiDocType, setAiDocType] = useState<TeachingDocType>('modul_ajar');
  const [aiGrade, setAiGrade] = useState('5');
  const [aiSemester, setAiSemester] = useState<'Ganjil' | 'Genap' | 'Tahunan'>('Ganjil');
  const [aiDomain, setAiDomain] = useState("Al-Qur'an & Hadis");
  const [aiTopic, setAiTopic] = useState("Menyayangi Anak Yatim & Surah Al-Ma'un");

  const refreshDocs = () => {
    setDocuments(StorageService.getTeachingDocs());
    setReferenceDocs(StorageService.getTeachingRefDocs());
  };

  const refreshReferenceDocs = () => {
    setReferenceDocs(StorageService.getTeachingRefDocs());
  };

  const handleStartAiGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiTopic.trim()) {
      showToast('Topik materi pokok wajib diisi!', 'error');
      return;
    }

    setIsGenerating(true);
    try {
      const selectedRef = referenceDocs.find(r => r.id === selectedAiRefId) || null;
      const generated = await AiTeachingDocService.generateDocument({
        docType: aiDocType,
        grade: aiGrade,
        semester: aiSemester,
        topic: aiTopic.trim(),
        domain: aiDomain,
        schoolName: appSettings.schoolName || teacherProfile.schoolName || 'SDN Ciketing Udik 2 Bantargebang',
        teacherName: teacherProfile.fullName || 'H. Ahmad Syarif, S.Pd.I',
        teacherNip: teacherProfile.nip || '198503152010011002',
        principalName: appSettings.principalName || 'Hj. Siti Aminah, M.Pd',
        principalNip: appSettings.principalNip || '197608201999032001',
        academicYear: appSettings.academicYear || '2026/2027',
        referenceDoc: selectedRef
      });
      setAiPreviewDoc(generated);
      showToast(
        selectedRef
          ? `Perangkat ajar berhasil disusun dengan sandaran "${selectedRef.title}"!`
          : 'Perangkat ajar berhasil disusun oleh AI! Silakan pratinjau sebelum menyimpan.',
        'success'
      );
    } catch (err: any) {
      console.error(err);
      showToast('Gagal menyusun dokumen: ' + (err?.message || 'Kesalahan sistem'), 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveAiDocument = () => {
    if (!aiPreviewDoc) return;
    StorageService.saveTeachingDoc(aiPreviewDoc);
    refreshDocs();
    showToast(`Dokumen "${aiPreviewDoc.title}" berhasil disimpan ke sistem!`, 'success');
    setAiPreviewDoc(null);
    setIsAiModalOpen(false);
  };

  const openManualInputModal = (typeOverride?: TeachingDocType, refDoc?: TeachingReferenceDoc | null) => {
    setEditingDoc(null);
    setActiveManualRefDoc(refDoc || null);
    const targetType = typeOverride || refDoc?.docType || (selectedDocType !== 'all' ? selectedDocType : 'cp_atp');
    setManualDefaultType(targetType);
    setIsManualModalOpen(true);
  };

  const openEditManualModal = (doc: TeachingDocument) => {
    setEditingDoc(doc);
    setActiveManualRefDoc(null);
    setManualDefaultType(doc.docType);
    setViewingDoc(null);
    setIsManualModalOpen(true);
  };

  const handleSaveManualDocument = (docPayload: Omit<TeachingDocument, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => {
    const saved = StorageService.saveTeachingDoc(docPayload);
    refreshDocs();
    setIsManualModalOpen(false);
    setEditingDoc(null);
    showToast(
      docPayload.id
        ? `Perangkat ajar "${saved.title}" berhasil diperbarui!`
        : `Perangkat ajar manual "${saved.title}" berhasil ditambahkan!`,
      'success'
    );
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    StorageService.deleteTeachingDoc(deleteTarget.id);
    setDocuments(prev => prev.filter(d => d.id !== deleteTarget.id));
    if (viewingDoc?.id === deleteTarget.id) setViewingDoc(null);
    if (printDoc?.id === deleteTarget.id) setPrintDoc(null);
    showToast(`Dokumen "${deleteTarget.title}" berhasil dihapus.`, 'info');
    setDeleteTarget(null);
  };

  const handlePrint = (doc: TeachingDocument) => {
    // Membuka langsung review dokumen di tab baru sesuai instruksi pengguna
    const opened = openDocumentInNewTab(doc, appSettings, teacherProfile);
    if (opened) {
      showToast('Dokumen resmi berhasil dibuka di tab baru untuk dicetak!', 'success');
    } else {
      // Jika browser memblokir popup tab baru, tampilkan pratinjau yang tidak mentok di layar
      setPrintDoc(doc);
      showToast('Tab baru terblokir oleh browser. Menampilkan pratinjau langsung di layar.', 'info');
    }
  };

  const handleOpenInAppPreview = (doc: TeachingDocument) => {
    setPrintDoc(doc);
  };

  const triggerBrowserPrint = () => {
    window.print();
  };

  // Filtered documents
  const filteredDocs = documents.filter(doc => {
    const matchGrade = selectedGrade === 'all' || doc.classGrade === selectedGrade;
    const matchType = selectedDocType === 'all' || doc.docType === selectedDocType;
    const matchSem = selectedSemester === 'all' || doc.semester === selectedSemester || doc.semester === 'Tahunan';
    const matchSearch = !searchQuery || 
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (doc.summary && doc.summary.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (doc.meta.targetBab && doc.meta.targetBab.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchGrade && matchType && matchSem && matchSearch;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl glass-strong border border-emerald-500/25 p-5 sm:p-7 shadow-xl">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                <BookOpen className="w-3.5 h-3.5" /> Perangkat Ajar Kurikulum Merdeka PAI SD
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-[11px] font-semibold">
                ⚖️ Acuan Resmi: Keputusan Kepala BKPDM No. 020 Th 2026
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-display text-white">
              Administrasi & Perangkat Ajar Berbasis Cinta (KBC)
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
              Lengkap dengan 6 instrumen resmi: <b>CP/ATP</b>, <b>Prota</b>, <b>Promes</b>, <b>KKTP</b>, <b>Modul Ajar (RPP)</b>, dan <b>LKPD</b> per tingkat kelas. Berlandaskan <b>Keputusan Kepala BKPDM Nomor 020 Tahun 2026</b> dengan pendekatan KBC (Kurikulum Berbasis Cinta).
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => {
                refreshReferenceDocs();
                setIsUploadRefModalOpen(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-bold text-xs sm:text-sm shadow-lg shadow-amber-500/25 flex items-center gap-2 cursor-pointer transition-all transform hover:-translate-y-0.5 border border-amber-400/30"
            >
              <Upload className="w-4 h-4 text-amber-100" />
              Upload Dokumen Acuan / CP ({referenceDocs.length})
            </button>

            <button
              type="button"
              onClick={() => openManualInputModal()}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-blue-500/25 flex items-center gap-2 cursor-pointer transition-all transform hover:-translate-y-0.5 border border-blue-400/30"
            >
              <Plus className="w-4 h-4" />
              + Input Manual Perangkat Ajar
            </button>

            <button
              type="button"
              onClick={() => {
                setAiPreviewDoc(null);
                setAiGrade(selectedGrade !== 'all' ? selectedGrade : '5');
                refreshReferenceDocs();
                setIsAiModalOpen(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-500/25 flex items-center gap-2 cursor-pointer transition-all transform hover:-translate-y-0.5"
            >
              <Sparkles className="w-4 h-4 text-amber-200" />
              Generate Dokumen AI
            </button>
          </div>
        </div>

        {/* Pintasan Cepat Input Manual Per Jenis Perangkat Ajar */}
        <div className="relative z-10 mt-5 pt-4 border-t border-white/10 flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold text-emerald-300 uppercase tracking-wider mr-1 flex items-center gap-1.5">
            <Edit2 className="w-3.5 h-3.5" /> Input Manual Cepat:
          </span>
          {DOC_TYPES.map(t => (
            <button
              key={t.id}
              type="button"
              onClick={() => openManualInputModal(t.id)}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-emerald-500/25 border border-white/15 hover:border-emerald-400/40 text-white hover:text-emerald-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-400" />
              Input {t.short}
            </button>
          ))}
          <button
            type="button"
            onClick={() => {
              refreshReferenceDocs();
              setIsUploadRefModalOpen(true);
            }}
            className="ml-auto px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all"
          >
            <FolderOpen className="w-3.5 h-3.5 text-amber-300" />
            Pustaka &amp; Upload Dokumen Acuan ({referenceDocs.length})
          </button>
        </div>

        {/* Strip Pustaka Dokumen Acuan / Sandaran Aktif */}
        {referenceDocs.length > 0 && (
          <div className="relative z-10 mt-3 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2 bg-amber-500/10 border border-amber-500/25 rounded-2xl px-3.5 py-2.5">
            <div className="flex items-center gap-2 text-xs text-amber-200">
              <Upload className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                Tersedia <b>{referenceDocs.length} Dokumen Acuan / Sandaran</b> (CP, ATP, Prota, dll.) siap dijadikan referensi pengisian:
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              {referenceDocs.slice(0, 3).map(ref => (
                <button
                  key={ref.id}
                  type="button"
                  onClick={() => openManualInputModal(ref.docType, ref)}
                  className="px-2.5 py-1 rounded-lg bg-slate-900/80 hover:bg-amber-500/25 border border-amber-500/30 text-[11px] font-bold text-amber-200 flex items-center gap-1 cursor-pointer transition-all"
                  title="Klik untuk mengisi perangkat ajar dengan sandaran dokumen ini"
                >
                  <span>📄 {ref.title.slice(0, 28)}{ref.title.length > 28 ? '...' : ''}</span>
                  <span className="text-emerald-300 ml-1 underline">Gunakan Acuan</span>
                </button>
              ))}
              <button
                type="button"
                onClick={() => setIsUploadRefModalOpen(true)}
                className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-bold text-white cursor-pointer"
              >
                Kelola Semua ({referenceDocs.length})
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Class Level Selector (Kelas 1 s/d 6) */}
      <div className="glass rounded-2xl p-2 sm:p-2.5 border border-white/10 flex items-center gap-1.5 sm:gap-2 overflow-x-auto scrollbar-thin">
        {[
          { id: 'all', label: 'Semua Kelas', sub: 'Kelas 1-6' },
          { id: '1', label: 'Kelas 1', sub: 'Fase A' },
          { id: '2', label: 'Kelas 2', sub: 'Fase A' },
          { id: '3', label: 'Kelas 3', sub: 'Fase B' },
          { id: '4', label: 'Kelas 4', sub: 'Fase B' },
          { id: '5', label: 'Kelas 5', sub: 'Fase C' },
          { id: '6', label: 'Kelas 6', sub: 'Fase C' }
        ].map(cls => {
          const isActive = selectedGrade === cls.id;
          return (
            <button
              key={cls.id}
              onClick={() => setSelectedGrade(cls.id)}
              className={`flex-1 min-w-[100px] py-2 px-3 rounded-xl text-center transition-all cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold shadow-md shadow-emerald-500/20'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300'
              }`}
            >
              <div className="text-xs sm:text-sm font-bold">{cls.label}</div>
              <div className={`text-[10px] ${isActive ? 'text-emerald-100' : 'text-slate-400'}`}>
                {cls.sub}
              </div>
            </button>
          );
        })}
      </div>

      {/* 6 Document Type Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-white/10 pb-3">
        <button
          onClick={() => setSelectedDocType('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            selectedDocType === 'all'
              ? 'bg-white/20 text-white border border-white/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          Semua Dokumen ({documents.filter(d => selectedGrade === 'all' || d.classGrade === selectedGrade).length})
        </button>
        {DOC_TYPES.map(t => {
          const count = documents.filter(
            d => d.docType === t.id && (selectedGrade === 'all' || d.classGrade === selectedGrade)
          ).length;
          const isActive = selectedDocType === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setSelectedDocType(t.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                isActive
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>{t.short}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/10 text-slate-300">
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Search and Secondary Filter */}
      <div className="glass rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 border border-white/10">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Cari materi, bab, atau judul perangkat..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={selectedSemester}
            onChange={e => setSelectedSemester(e.target.value)}
            className="w-full sm:w-44 px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-xs text-white"
          >
            <option value="all">Semua Semester</option>
            <option value="Ganjil">Semester Ganjil</option>
            <option value="Genap">Semester Genap</option>
            <option value="Tahunan">Tahunan</option>
          </select>
        </div>
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDocs.length === 0 ? (
          <div className="col-span-full glass rounded-3xl p-10 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mx-auto text-slate-400">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-white text-base">Belum Ada Dokumen di Kategori Ini</h3>
            <p className="text-slate-400 text-xs max-w-md mx-auto leading-relaxed">
              Silakan tambahkan perangkat ajar untuk <b>Kelas {selectedGrade === 'all' ? '1-6' : selectedGrade}</b> secara <b>Input Manual</b> (CP/ATP, Prota, Promes, KKTP, Modul Ajar, LKPD, &amp; Lainnya) atau gunakan bantuan AI.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => openManualInputModal()}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer transition-colors shadow-lg shadow-blue-600/20"
              >
                <Plus className="w-3.5 h-3.5" /> + Input Manual Sekarang
              </button>
              <button
                type="button"
                onClick={() => {
                  setAiPreviewDoc(null);
                  setAiGrade(selectedGrade !== 'all' ? selectedGrade : '5');
                  setIsAiModalOpen(true);
                }}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 text-white font-bold text-xs cursor-pointer hover:bg-emerald-600 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" /> Susun dengan AI Sekarang
              </button>
            </div>
          </div>
        ) : (
          filteredDocs.map(doc => {
            const typeConfig = DOC_TYPES.find(t => t.id === doc.docType) || DOC_TYPES[0];
            return (
              <div
                key={doc.id}
                className="glass rounded-2xl p-5 border border-white/10 hover:border-emerald-500/40 transition-all shadow-md flex flex-col justify-between space-y-4 group"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-[10px] tracking-wide">
                      Kelas {doc.classGrade} &bull; {doc.meta.fase}
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-white/10 text-slate-300 font-semibold text-[10px] uppercase">
                      {typeConfig.short}
                    </span>
                  </div>

                  <h3 className="font-bold text-sm sm:text-base text-white group-hover:text-emerald-300 transition-colors line-clamp-2 leading-snug">
                    {doc.title}
                  </h3>

                  <p className="text-xs text-slate-300 mt-2 line-clamp-3 leading-relaxed opacity-90">
                    {doc.summary || 'Dokumen perangkat ajar PAI & Budi Pekerti berorientasi Kurikulum Merdeka.'}
                  </p>

                  <div className="mt-3 pt-3 border-t border-white/5 flex flex-wrap gap-2 text-[11px] text-slate-400">
                    <span className="inline-flex items-center gap-1">
                      <Layers className="w-3 h-3 text-cyan-400" /> {doc.meta.elementDomain}
                    </span>
                    <span className="inline-flex items-center gap-1 text-emerald-400 font-medium">
                      <HeartHandshake className="w-3 h-3" /> KBC
                    </span>
                    {doc.contentData.sandaranAcuan && (
                      <span
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500/15 border border-amber-500/30 text-amber-300 font-semibold text-[10px]"
                        title={`Disusun dengan sandaran: ${doc.contentData.sandaranAcuan.referenceTitle} (${doc.contentData.sandaranAcuan.fileName || ''})`}
                      >
                        📎 Acuan: {(doc.contentData.sandaranAcuan.fileName || doc.contentData.sandaranAcuan.referenceTitle).slice(0, 18)}
                      </span>
                    )}
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setViewingDoc(doc)}
                      className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
                      title="Lihat Rincian Dokumen"
                    >
                      <Eye className="w-3.5 h-3.5 text-cyan-400" /> Detail
                    </button>
                    <button
                      onClick={() => openEditManualModal(doc)}
                      className="px-2.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
                      title="Edit Manual Dokumen Ini"
                    >
                      <Edit2 className="w-3.5 h-3.5" /> Edit
                    </button>
                    <button
                      onClick={() => handlePrint(doc)}
                      className="px-2.5 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center gap-1 cursor-pointer transition-all shadow-sm shadow-emerald-500/10"
                      title="Langsung Buka Review & Cetak di Tab Baru"
                    >
                      <ExternalLink className="w-3.5 h-3.5" /> Cetak
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeleteTarget({ id: doc.id, title: doc.title });
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 cursor-pointer transition-colors"
                    title="Hapus Dokumen"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* AI GENERATOR MODAL */}
      {isAiModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col border border-emerald-500/30 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Generator Perangkat Ajar AI (KBC)</h3>
                  <p className="text-[11px] text-slate-400">
                    Standar Kurikulum Merdeka PAI SD &amp; Pendekatan Cinta Kasih Sayang
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAiModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {!aiPreviewDoc ? (
              <form onSubmit={handleStartAiGenerate} className="p-5 overflow-y-auto flex-1 space-y-4">
                <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-200 leading-relaxed">
                  💡 <b>Pemberitahuan Otomatis:</b> Generator ini akan menyusun instrumen resmi secara utuh (bukan sekadar kerangka), menyisipkan ayat/khat Naskh rapi, dan mencantumkan nama sekolah <b>"{appSettings.schoolName || 'SDN Ciketing Udik 2 Bantargebang'}"</b> pada setting konteks pembelajaran.
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                      Jenis Perangkat Ajar <span className="text-rose-400">*</span>
                    </label>
                    <select
                      value={aiDocType}
                      onChange={e => setAiDocType(e.target.value as any)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs sm:text-sm font-bold"
                    >
                      {DOC_TYPES.map(t => (
                        <option key={t.id} value={t.id}>
                          {t.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                      Tingkat Kelas &amp; Fase <span className="text-rose-400">*</span>
                    </label>
                    <select
                      value={aiGrade}
                      onChange={e => setAiGrade(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs sm:text-sm font-bold"
                    >
                      <option value="1">Kelas 1 (Fase A)</option>
                      <option value="2">Kelas 2 (Fase A)</option>
                      <option value="3">Kelas 3 (Fase B)</option>
                      <option value="4">Kelas 4 (Fase B)</option>
                      <option value="5">Kelas 5 (Fase C)</option>
                      <option value="6">Kelas 6 (Fase C)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                      Semester <span className="text-rose-400">*</span>
                    </label>
                    <select
                      value={aiSemester}
                      onChange={e => setAiSemester(e.target.value as any)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs sm:text-sm font-bold"
                    >
                      <option value="Ganjil">Semester Ganjil</option>
                      <option value="Genap">Semester Genap</option>
                      <option value="Tahunan">Tahunan (Untuk Prota/ATP)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                      Elemen PAI <span className="text-rose-400">*</span>
                    </label>
                    <select
                      value={aiDomain}
                      onChange={e => setAiDomain(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs sm:text-sm font-bold"
                    >
                      <option value="Al-Qur'an & Hadis">Al-Qur'an &amp; Hadis</option>
                      <option value="Akidah">Akidah (Asmaul Husna &amp; Rukun Iman)</option>
                      <option value="Akhlak">Akhlak Mulia &amp; Adab Keseharian</option>
                      <option value="Fikih">Fikih (Ibadah Shalat, Thaharah, Zakat)</option>
                      <option value="Sejarah Peradaban Islam">Sejarah Peradaban Islam (Kisah Nabi &amp; Sahabat)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                    Materi Pokok / Bab Pembelajaran <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={aiTopic}
                    onChange={e => setAiTopic(e.target.value)}
                    placeholder="Contoh: Menyayangi Anak Yatim & Surah Al-Ma'un"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
                    required
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Ketik topik atau pilih tema kurikulum merdeka. AI akan mengintegrasikan nilai Kurikulum Berbasis Cinta (KBC).
                  </p>
                </div>

                {/* Sandaran / Dokumen Acuan untuk AI */}
                <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <label className="text-xs font-bold text-amber-300 uppercase flex items-center gap-1.5">
                      <Upload className="w-3.5 h-3.5" /> Sandaran Dokumen Acuan / CP (Opsional)
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setIsAiModalOpen(false);
                        setIsUploadRefModalOpen(true);
                      }}
                      className="text-[11px] font-bold text-amber-300 hover:text-amber-200 underline cursor-pointer"
                    >
                      + Upload Dokumen Acuan Baru
                    </button>
                  </div>
                  <select
                    value={selectedAiRefId}
                    onChange={e => setSelectedAiRefId(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-amber-500/30 text-white text-xs font-semibold"
                  >
                    <option value="">-- Tanpa Dokumen Acuan (Gunakan Standar Kurikulum Merdeka) --</option>
                    {referenceDocs.map(ref => (
                      <option key={ref.id} value={ref.id}>
                        📄 {ref.title} (Kelas {ref.classGrade} • {ref.fileName})
                      </option>
                    ))}
                  </select>
                  <p className="text-[11px] text-slate-400">
                    Jika dipilih, isi dokumen CP/ATP/Prota yang Anda upload akan dijadikan acuan utama dalam menyusun perangkat ajar ini.
                  </p>
                </div>

                <div className="pt-3 border-t border-white/10 flex items-center justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setIsAiModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={isGenerating}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-lg shadow-emerald-500/20 cursor-pointer transition-all flex items-center gap-2 disabled:opacity-50"
                  >
                    {isGenerating ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        AI Sedang Menyusun Dokumen...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-amber-200" />
                        Mulai Susun dengan AI
                      </>
                    )}
                  </button>
                </div>
              </form>
            ) : (
              /* AI PREVIEW MODE */
              <div className="p-5 overflow-y-auto flex-1 space-y-4">
                <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-between text-xs text-emerald-300">
                  <span className="flex items-center gap-2 font-bold">
                    <CheckCircle2 className="w-4 h-4" /> Dokumen Berhasil Disusun
                  </span>
                  <span className="text-[11px] opacity-80">
                    Tipe: {aiPreviewDoc.docType.toUpperCase()} &bull; Kelas {aiPreviewDoc.classGrade}
                  </span>
                </div>

                <div>
                  <h4 className="font-bold text-base text-white">{aiPreviewDoc.title}</h4>
                  <p className="text-xs text-slate-300 mt-1">{aiPreviewDoc.summary}</p>
                </div>

                {/* Render brief content preview */}
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 text-xs text-slate-200 space-y-3 max-h-72 overflow-y-auto scrollbar-thin">
                  {aiPreviewDoc.contentData.capaianPembelajaran && (
                    <div>
                      <span className="font-bold text-emerald-400 block mb-1">Capaian Pembelajaran:</span>
                      <p className="leading-relaxed">{aiPreviewDoc.contentData.capaianPembelajaran}</p>
                    </div>
                  )}

                  {aiPreviewDoc.contentData.alurTujuanPembelajaran && (
                    <div>
                      <span className="font-bold text-emerald-400 block mb-1">Alur Tujuan Pembelajaran:</span>
                      <ul className="list-disc pl-4 space-y-1">
                        {aiPreviewDoc.contentData.alurTujuanPembelajaran.map((atp, i) => (
                          <li key={i}>{atp.tujuan} ({atp.alokasiJP} JP)</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {aiPreviewDoc.contentData.protaItems && (
                    <div>
                      <span className="font-bold text-emerald-400 block mb-1">Daftar Materi Prota ({aiPreviewDoc.contentData.protaItems.length} Bab):</span>
                      <ul className="list-disc pl-4 space-y-1">
                        {aiPreviewDoc.contentData.protaItems.slice(0, 4).map((item, i) => (
                          <li key={i}>{item.materiPokok} - {item.alokasiJP} JP</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {aiPreviewDoc.contentData.modulAjar && (
                    <div>
                      <span className="font-bold text-emerald-400 block mb-1">Komponen Modul Ajar:</span>
                      <p><b>Model:</b> {aiPreviewDoc.contentData.modulAjar.modelPembelajaran}</p>
                      <p className="mt-1"><b>Tujuan:</b> {aiPreviewDoc.contentData.modulAjar.komponenInti.tujuanPembelajaran[0]}</p>
                    </div>
                  )}

                  {aiPreviewDoc.contentData.lkpd && (
                    <div>
                      <span className="font-bold text-emerald-400 block mb-1">Aktivitas LKPD Ceria:</span>
                      <p>{aiPreviewDoc.contentData.lkpd.judulAktivitas}</p>
                      {aiPreviewDoc.contentData.lkpd.arabicSnippet && (
                        <p className="font-serif text-sm text-amber-200 mt-1" dir="rtl">
                          {aiPreviewDoc.contentData.lkpd.arabicSnippet.text}
                        </p>
                      )}
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t border-white/10 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setAiPreviewDoc(null)}
                    className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                  >
                    Kembali &amp; Edit Form
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handlePrint(aiPreviewDoc)}
                      className="px-4 py-2.5 rounded-xl bg-blue-500/20 text-blue-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer hover:bg-blue-500/30 transition-colors"
                    >
                      <Printer className="w-4 h-4" /> Cetak Langsung
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveAiDocument}
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-lg shadow-emerald-500/20 cursor-pointer transition-all flex items-center gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4" /> Simpan ke Perangkat Ajar
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* DETAIL MODAL */}
      {viewingDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                  Perangkat Ajar &bull; Kelas {viewingDoc.classGrade} ({viewingDoc.meta.fase}) &bull; {viewingDoc.semester}
                </span>
                <h3 className="font-bold text-base sm:text-lg text-white">{viewingDoc.title}</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handlePrint(viewingDoc)}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer hover:bg-emerald-500/30 transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" /> Cetak Resmi
                </button>
                <button
                  onClick={() => setViewingDoc(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto flex-1 text-slate-200 text-xs sm:text-sm space-y-6 leading-relaxed">
              {/* Document Summary */}
              {viewingDoc.summary && (
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
                  <h4 className="font-bold text-emerald-400 text-xs uppercase mb-1">Ringkasan Dokumen:</h4>
                  <p>{viewingDoc.summary}</p>
                </div>
              )}

              {/* CP/ATP View */}
              {viewingDoc.docType === 'cp_atp' && (
                <div className="space-y-4">
                  {viewingDoc.contentData.capaianPembelajaran && (
                    <div>
                      <h4 className="font-bold text-sm text-white mb-2">Capaian Pembelajaran (CP):</h4>
                      <p className="p-4 rounded-xl bg-slate-900 border border-white/10 text-slate-300 leading-relaxed">
                        {viewingDoc.contentData.capaianPembelajaran}
                      </p>
                    </div>
                  )}

                  {viewingDoc.contentData.alurTujuanPembelajaran && (
                    <div>
                      <h4 className="font-bold text-sm text-white mb-2">Matriks Alur Tujuan Pembelajaran (ATP):</h4>
                      <div className="overflow-x-auto rounded-xl border border-white/15">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead className="bg-white/10 text-slate-200">
                            <tr>
                              <th className="p-2.5 border-b border-white/10 w-10 text-center">No</th>
                              <th className="p-2.5 border-b border-white/10">Tujuan Pembelajaran (TP)</th>
                              <th className="p-2.5 border-b border-white/10">Materi Pokok</th>
                              <th className="p-2.5 border-b border-white/10">Profil Pelajar KBC</th>
                              <th className="p-2.5 border-b border-white/10 text-center w-16">Alokasi</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                            {viewingDoc.contentData.alurTujuanPembelajaran.map((atp, i) => (
                              <tr key={i} className="hover:bg-white/5">
                                <td className="p-2.5 text-center">{atp.no || i + 1}</td>
                                <td className="p-2.5 font-medium text-white">{atp.tujuan}</td>
                                <td className="p-2.5 text-slate-300">{atp.materi}</td>
                                <td className="p-2.5 text-emerald-400">{atp.profilPancasilaKBC}</td>
                                <td className="p-2.5 text-center font-bold text-cyan-400">{atp.alokasiJP} JP</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* PROTA View */}
              {viewingDoc.docType === 'prota' && viewingDoc.contentData.protaItems && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-xs font-bold text-emerald-400 bg-emerald-500/10 p-3 rounded-xl border border-emerald-500/20">
                    <span>Total Alokasi 1 Tahun Ajaran: {viewingDoc.contentData.totalJPTahunan || 108} JP</span>
                    <span>Ganjil: {viewingDoc.contentData.totalJPGanjil || 54} JP | Genap: {viewingDoc.contentData.totalJPGenap || 54} JP</span>
                  </div>

                  <div className="overflow-x-auto rounded-xl border border-white/15">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-white/10 text-slate-200">
                        <tr>
                          <th className="p-2.5 border-b border-white/10 w-10 text-center">No</th>
                          <th className="p-2.5 border-b border-white/10">Semester</th>
                          <th className="p-2.5 border-b border-white/10">Materi Pokok / Bab</th>
                          <th className="p-2.5 border-b border-white/10">Tujuan Pembelajaran</th>
                          <th className="p-2.5 border-b border-white/10 text-center w-16">JP</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {viewingDoc.contentData.protaItems.map((item, i) => (
                          <tr key={i} className="hover:bg-white/5">
                            <td className="p-2.5 text-center">{item.no}</td>
                            <td className="p-2.5">
                              <span className="px-2 py-0.5 rounded bg-white/10 text-[10px] font-bold">
                                {item.semester}
                              </span>
                            </td>
                            <td className="p-2.5 font-bold text-white">{item.materiPokok}</td>
                            <td className="p-2.5 text-slate-300">{item.tujuanPembelajaran}</td>
                            <td className="p-2.5 text-center font-bold text-emerald-400">{item.alokasiJP} JP</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* PROMES View */}
              {viewingDoc.docType === 'promes' && viewingDoc.contentData.promesItems && (
                <div className="space-y-4">
                  <div className="overflow-x-auto rounded-xl border border-white/15">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-white/10 text-slate-200">
                        <tr>
                          <th className="p-2.5 border-b border-white/10 w-10 text-center">No</th>
                          <th className="p-2.5 border-b border-white/10">Materi Pokok</th>
                          <th className="p-2.5 border-b border-white/10">Tujuan Pembelajaran</th>
                          <th className="p-2.5 border-b border-white/10 text-center w-16">Alokasi</th>
                          <th className="p-2.5 border-b border-white/10">Distribusi Bulan</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {viewingDoc.contentData.promesItems.map((item, i) => (
                          <tr key={i} className="hover:bg-white/5">
                            <td className="p-2.5 text-center">{item.no}</td>
                            <td className="p-2.5 font-bold text-white">{item.materiPokok}</td>
                            <td className="p-2.5 text-slate-300">{item.tujuanPembelajaran}</td>
                            <td className="p-2.5 text-center font-bold text-cyan-400">{item.alokasiJP} JP</td>
                            <td className="p-2.5 text-slate-400">
                              {item.distribusiBulan.map(b => `${b.bulan}`).join(', ')}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* KKTP View */}
              {viewingDoc.docType === 'kktp' && viewingDoc.contentData.kktpItems && (
                <div className="space-y-4">
                  {viewingDoc.contentData.kktpItems.map((kktp, idx) => (
                    <div key={idx} className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-xs">
                          {kktp.no}
                        </span>
                        <h4 className="font-bold text-white text-sm">{kktp.tujuanPembelajaran}</h4>
                      </div>
                      <p className="text-xs text-slate-300"><b>Indikator:</b> {kktp.indikatorKetuntasan}</p>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-2 border-t border-white/5 text-[11px]">
                        <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20">
                          <span className="font-bold text-rose-300 block mb-1">Perlu Bimbingan (0-60)</span>
                          <p className="text-slate-300">{kktp.kriteria.perluBimbingan}</p>
                        </div>
                        <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20">
                          <span className="font-bold text-amber-300 block mb-1">Cukup (61-75)</span>
                          <p className="text-slate-300">{kktp.kriteria.cukup}</p>
                        </div>
                        <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20">
                          <span className="font-bold text-blue-300 block mb-1">Baik (76-88)</span>
                          <p className="text-slate-300">{kktp.kriteria.baik}</p>
                        </div>
                        <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                          <span className="font-bold text-emerald-300 block mb-1">Sangat Baik (89-100)</span>
                          <p className="text-slate-300">{kktp.kriteria.sangatBaik}</p>
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-300 text-xs flex items-center gap-2">
                        <HeartHandshake className="w-4 h-4 shrink-0" />
                        <span><b>Tindak Lanjut Kasih Sayang (KBC):</b> {kktp.tindakLanjutKBC}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* MODUL AJAR View */}
              {viewingDoc.docType === 'modul_ajar' && viewingDoc.contentData.modulAjar && (
                <div className="space-y-5">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-white/5 border border-white/10 text-xs">
                    <div><b>Penyusun:</b> {viewingDoc.contentData.modulAjar.identitas.penyusun}</div>
                    <div><b>Instansi:</b> {viewingDoc.contentData.modulAjar.identitas.instansi}</div>
                    <div><b>Kelas / Fase:</b> {viewingDoc.contentData.modulAjar.identitas.faseKelas}</div>
                    <div><b>Alokasi Waktu:</b> {viewingDoc.contentData.modulAjar.identitas.alokasiWaktu}</div>
                    <div><b>Model:</b> {viewingDoc.contentData.modulAjar.modelPembelajaran}</div>
                    <div><b>Target:</b> {viewingDoc.contentData.modulAjar.targetPesertaDidik}</div>
                  </div>

                  <div>
                    <h4 className="font-bold text-emerald-400 text-sm mb-1">Tujuan Pembelajaran:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-slate-300">
                      {viewingDoc.contentData.modulAjar.komponenInti.tujuanPembelajaran.map((tp, i) => (
                        <li key={i}>{tp}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                    <h4 className="font-bold text-emerald-300 text-xs uppercase mb-1">Pemahaman Bermakna (KBC):</h4>
                    <p className="text-slate-200">{viewingDoc.contentData.modulAjar.komponenInti.pemahamanBermakna}</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-emerald-400 text-sm mb-2">Langkah-Langkah Kegiatan Pembelajaran:</h4>
                    <div className="space-y-3">
                      <div className="p-3 rounded-xl bg-slate-900 border border-white/10">
                        <span className="font-bold text-amber-300 block mb-1">A. Kegiatan Pendahuluan:</span>
                        <ul className="list-disc pl-5 space-y-1 text-slate-300">
                          {viewingDoc.contentData.modulAjar.komponenInti.kegiatanPembelajaran.pendahuluan.map((act, i) => (
                            <li key={i}>{act}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-900 border border-white/10">
                        <span className="font-bold text-emerald-300 block mb-1">B. Kegiatan Inti:</span>
                        <ul className="list-disc pl-5 space-y-1 text-slate-300">
                          {viewingDoc.contentData.modulAjar.komponenInti.kegiatanPembelajaran.kegiatanInti.map((act, i) => (
                            <li key={i}>{act}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-900 border border-white/10">
                        <span className="font-bold text-cyan-300 block mb-1">C. Kegiatan Penutup:</span>
                        <ul className="list-disc pl-5 space-y-1 text-slate-300">
                          {viewingDoc.contentData.modulAjar.komponenInti.kegiatanPembelajaran.penutup.map((act, i) => (
                            <li key={i}>{act}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* LKPD View */}
              {viewingDoc.docType === 'lkpd' && viewingDoc.contentData.lkpd && (
                <div className="space-y-5">
                  <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20">
                    <h4 className="font-bold text-emerald-300 text-base">{viewingDoc.contentData.lkpd.judulAktivitas}</h4>
                    <p className="text-xs text-slate-300 mt-1"><b>Nilai KBC:</b> {viewingDoc.contentData.lkpd.temaNilaiKBC}</p>
                  </div>

                  {viewingDoc.contentData.lkpd.stimulusCerita && (
                    <div className="p-4 rounded-2xl bg-slate-900 border border-white/15 space-y-2">
                      <span className="text-xs font-bold text-amber-300 uppercase block">Stimulus Cerita Kontekstual:</span>
                      <p className="text-slate-200 leading-relaxed italic">{viewingDoc.contentData.lkpd.stimulusCerita}</p>
                    </div>
                  )}

                  {viewingDoc.contentData.lkpd.arabicSnippet && (
                    <div className="p-4 rounded-2xl bg-white/5 border border-white/15 text-center space-y-2">
                      <p className="font-serif text-xl sm:text-2xl text-emerald-300 leading-loose" dir="rtl">
                        {viewingDoc.contentData.lkpd.arabicSnippet.text}
                      </p>
                      <p className="text-xs text-slate-300 italic">"{viewingDoc.contentData.lkpd.arabicSnippet.arti}"</p>
                    </div>
                  )}

                  <div>
                    <h4 className="font-bold text-sm text-white mb-2">Tugas &amp; Aktivitas Murid:</h4>
                    <div className="space-y-3">
                      {viewingDoc.contentData.lkpd.tugasSiswa.map(tugas => (
                        <div key={tugas.nomor} className="p-3.5 rounded-xl bg-slate-900 border border-white/10 space-y-2">
                          <div className="font-bold text-white text-xs">
                            {tugas.nomor}. {tugas.instruksi}
                          </div>
                          {tugas.opsi && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-4">
                              {tugas.opsi.map((opt, oi) => (
                                <div key={oi} className="p-2 rounded-lg bg-white/5 border border-white/5 text-xs text-slate-300">
                                  {String.fromCharCode(65 + oi)}. {opt}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* DOKUMEN LAINNYA View */}
              {viewingDoc.docType === 'lainnya' && viewingDoc.contentData.dokumenLainnya && (
                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-teal-500/10 border border-teal-500/30 space-y-1">
                    <span className="text-[11px] font-bold uppercase text-teal-300">
                      Kategori: {viewingDoc.contentData.dokumenLainnya.subKategori}
                    </span>
                    {viewingDoc.contentData.dokumenLainnya.tujuanDokumen && (
                      <p className="text-xs text-slate-200">
                        <b>Tujuan / Sasaran:</b> {viewingDoc.contentData.dokumenLainnya.tujuanDokumen}
                      </p>
                    )}
                  </div>

                  {viewingDoc.contentData.dokumenLainnya.uraianIsi && (
                    <div className="p-4 rounded-2xl bg-slate-900 border border-white/10 whitespace-pre-line text-xs text-slate-200 leading-relaxed">
                      <h4 className="font-bold text-emerald-400 uppercase mb-1.5">Uraian Isi Dokumen:</h4>
                      {viewingDoc.contentData.dokumenLainnya.uraianIsi}
                    </div>
                  )}

                  {viewingDoc.contentData.dokumenLainnya.tabelBaris &&
                    viewingDoc.contentData.dokumenLainnya.tabelBaris.length > 0 && (
                      <div className="overflow-x-auto rounded-xl border border-white/15">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead className="bg-white/10 text-slate-200">
                            <tr>
                              <th className="p-2.5 border-b border-white/10 w-10 text-center">No</th>
                              <th className="p-2.5 border-b border-white/10">Aspek / Komponen</th>
                              <th className="p-2.5 border-b border-white/10">Uraian / Indikator</th>
                              <th className="p-2.5 border-b border-white/10 text-center w-24">Keterangan</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                            {viewingDoc.contentData.dokumenLainnya.tabelBaris.map((row, i) => (
                              <tr key={i} className="hover:bg-white/5">
                                <td className="p-2.5 text-center">{row.no || i + 1}</td>
                                <td className="p-2.5 font-bold text-white">{row.aspek}</td>
                                <td className="p-2.5 text-slate-300">{row.uraian}</td>
                                <td className="p-2.5 text-center font-bold text-emerald-400">{row.keterangan}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}

                  {viewingDoc.contentData.dokumenLainnya.tautanBukti && (
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs">
                      <span className="text-slate-300 truncate">
                        <b>Tautan Dokumen:</b> {viewingDoc.contentData.dokumenLainnya.tautanBukti}
                      </span>
                      <a
                        href={viewingDoc.contentData.dokumenLainnya.tautanBukti}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 font-bold hover:bg-cyan-500/30 shrink-0 ml-2"
                      >
                        Buka Link ↗
                      </a>
                    </div>
                  )}

                  {viewingDoc.contentData.dokumenLainnya.lampiranFile && (
                    <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between text-xs">
                      <span className="text-emerald-200 font-semibold">
                        📎 Lampiran File: {viewingDoc.contentData.dokumenLainnya.lampiranFile.fileName}
                      </span>
                      <a
                        href={viewingDoc.contentData.dokumenLainnya.lampiranFile.dataUrl}
                        download={viewingDoc.contentData.dokumenLainnya.lampiranFile.fileName}
                        className="px-3 py-1 rounded-lg bg-emerald-500 text-white font-bold hover:bg-emerald-600 shrink-0 ml-2 flex items-center gap-1"
                      >
                        <Download className="w-3.5 h-3.5" /> Unduh File
                      </a>
                    </div>
                  )}
                </div>
              )}

              {viewingDoc.contentData.catatanTambahan && (
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-xs text-amber-100 whitespace-pre-line">
                  <h4 className="font-bold text-amber-300 uppercase mb-1">Catatan Tambahan Guru:</h4>
                  {viewingDoc.contentData.catatanTambahan}
                </div>
              )}
            </div>

            <div className="p-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setDeleteTarget({ id: viewingDoc.id, title: viewingDoc.title });
                  }}
                  className="px-3.5 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Hapus
                </button>
                <button
                  type="button"
                  onClick={() => openEditManualModal(viewingDoc)}
                  className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Edit2 className="w-3.5 h-3.5" /> Edit Manual Dokumen
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleOpenInAppPreview(viewingDoc)}
                  className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Eye className="w-3.5 h-3.5 text-cyan-400" /> Pratinjau di Layar
                </button>
                <button
                  onClick={() => handlePrint(viewingDoc)}
                  className="px-6 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-lg shadow-emerald-500/20 cursor-pointer flex items-center gap-2"
                >
                  <ExternalLink className="w-4 h-4" /> Buka di Tab Baru &amp; Cetak
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* OFFICIAL PRINT PREVIEW (SCROLLABLE & NEVER TRAPPED) */}
      {printDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md overflow-y-auto block p-2 sm:p-6 print:p-0 print:bg-white print:overflow-visible">
          {/* Top Sticky Toolbar with Prominent Return Button - ALWAYS VISIBLE */}
          <div className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur border border-white/15 px-4 py-3 rounded-2xl mb-6 shadow-2xl flex flex-wrap items-center justify-between gap-3 text-white max-w-4xl mx-auto no-print">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setPrintDoc(null)}
                className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-rose-600/30 cursor-pointer transition-all"
              >
                <ArrowLeft className="w-4 h-4" /> ← Kembali ke Menu Utama
              </button>
              <span className="hidden sm:inline-block px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                ⚖️ Acuan: Keputusan Kepala BKPDM No. 020 Th 2026 (KBC)
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  const opened = openDocumentInNewTab(printDoc, appSettings, teacherProfile);
                  if (opened) {
                    showToast('Dokumen berhasil dibuka di tab baru!', 'success');
                  } else {
                    showToast('Pop-up terblokir oleh browser. Anda tetap dapat mencetak melalui tombol Cetak PDF.', 'info');
                  }
                }}
                className="px-3.5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
                title="Buka dokumen di tab baru untuk pencetakan resmi"
              >
                <ExternalLink className="w-3.5 h-3.5" /> Buka di Tab Baru ↗
              </button>
              <button
                type="button"
                onClick={triggerBrowserPrint}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/30 cursor-pointer transition-all"
              >
                <Printer className="w-4 h-4" /> Cetak ke Printer / PDF
              </button>
            </div>
          </div>

          <div className="bg-white text-black w-full max-w-4xl rounded-2xl shadow-2xl p-6 sm:p-10 mx-auto my-0 relative print:p-0 print:m-0 print:w-full print:shadow-none print:rounded-none">
            {/* Header info inside paper */}

            {/* PRINT CONTENT: KOP SURAT RESMI */}
            <div className="border-b-[3px] border-double border-black pb-3 mb-6 flex items-center gap-5">
              <img
                src={appSettings.appLogoUrl || 'https://jhlryjdhotxtndavacpd.supabase.co/storage/v1/object/public/logo/logo.png'}
                alt="Logo Satuan Pendidikan"
                className="w-20 h-20 object-contain shrink-0"
                onError={e => { (e.target as HTMLElement).style.display = 'none'; }}
              />
              <div className="text-center flex-1">
                <h4 className="text-xs sm:text-sm font-semibold tracking-wider uppercase">
                  PEMERINTAH KOTA BEKASI &bull; DINAS PENDIDIKAN
                </h4>
                <h2 className="text-base sm:text-xl font-extrabold uppercase tracking-wide mt-0.5">
                  {printDoc.schoolName || appSettings.schoolName || 'SDN CIKETING UDIK 2 BANTARGEBANG'}
                </h2>
                <p className="text-[11px] text-slate-700 mt-1 leading-tight">
                  {appSettings.schoolAddress || 'Jl. Raya Ciketing Udik No. 2, Kec. Bantargebang, Kota Bekasi, Jawa Barat'}
                </p>
                <p className="text-[10px] text-slate-600 mt-0.5 font-mono">
                  Mata Pelajaran: PAI &amp; Budi Pekerti &bull; Tahun Ajaran: {printDoc.academicYear || '2026/2027'}
                </p>
              </div>
            </div>

            {/* DOKUMEN HEADER & IDENTITAS */}
            <div className="text-center my-5">
              <h3 className="text-base sm:text-lg font-extrabold uppercase underline tracking-wide">
                {printDoc.title}
              </h3>
              <p className="text-xs font-semibold text-slate-700 mt-1">
                Fase {printDoc.meta.fase} &bull; Tingkat Kelas {printDoc.classGrade} &bull; Semester {printDoc.semester}
              </p>
              <div className="inline-block mt-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-300 text-[10px] font-bold">
                ⚖️ Regulasi Acuan: {REGULASI_RESMI_BKPDM}
              </div>
            </div>

            {/* IDENTITAS TABEL SINGKAT */}
            <table className="w-full text-xs mb-6 border border-black/40">
              <tbody>
                <tr className="border-b border-black/20">
                  <td className="p-2 font-bold w-40 bg-slate-50">Satuan Pendidikan</td>
                  <td className="p-2">{printDoc.schoolName}</td>
                  <td className="p-2 font-bold w-40 bg-slate-50">Fase / Kelas</td>
                  <td className="p-2">{printDoc.meta.fase} / Kelas {printDoc.classGrade}</td>
                </tr>
                <tr className="border-b border-black/20">
                  <td className="p-2 font-bold bg-slate-50">Mata Pelajaran</td>
                  <td className="p-2">Pendidikan Agama Islam &amp; Budi Pekerti</td>
                  <td className="p-2 font-bold bg-slate-50">Tahun Pelajaran</td>
                  <td className="p-2">{printDoc.academicYear || '2026/2027'}</td>
                </tr>
                <tr className="border-b border-black/20">
                  <td className="p-2 font-bold bg-slate-50">Elemen / Pendekatan</td>
                  <td className="p-2">{printDoc.meta.elementDomain} &bull; {printDoc.meta.pendekatan}</td>
                  <td className="p-2 font-bold bg-slate-50">Guru Pengampu</td>
                  <td className="p-2">{printDoc.teacherName}</td>
                </tr>
                <tr>
                  <td className="p-2 font-bold bg-slate-50">Dasar Regulasi</td>
                  <td colSpan={3} className="p-2 font-medium">{REGULASI_RESMI_BKPDM}</td>
                </tr>
              </tbody>
            </table>

            {/* ISI RESMI PER JENIS DOKUMEN */}
            <div className="text-xs leading-relaxed space-y-5 text-black">
              {/* CP / ATP */}
              {printDoc.docType === 'cp_atp' && (
                <>
                  <div className="space-y-1.5">
                    <h5 className="font-bold text-sm uppercase">I. Dasar Hukum &amp; Regulasi CP/ATP</h5>
                    <div className="text-xs p-3 rounded bg-emerald-50 border border-emerald-200 text-emerald-900 leading-relaxed">
                      <b>Pedoman Regulasi:</b> {REGULASI_RESMI_BKPDM}.<br />
                      <b>Prinsip Pembelajaran:</b> Mengedepankan kasih sayang (mahabbah), keteladanan akhlak mulia, dan suasana belajar yang menyejukkan tanpa kekerasan di lingkungan satuan pendidikan.
                    </div>
                  </div>

                  <div className="space-y-1.5 mt-3">
                    <h5 className="font-bold text-sm uppercase">II. Capaian Pembelajaran (CP)</h5>
                    <p className="text-justify border p-3 rounded bg-slate-50">
                      {printDoc.contentData.capaianPembelajaran}
                    </p>
                  </div>

                  {printDoc.contentData.alurTujuanPembelajaran && (
                    <div className="space-y-1.5 mt-3">
                      <h5 className="font-bold text-sm uppercase">III. Alur Tujuan Pembelajaran (ATP)</h5>
                      <table className="w-full text-left border border-black border-collapse">
                        <thead>
                          <tr className="bg-slate-100 border-b border-black font-bold">
                            <th className="p-2 border-r border-black text-center w-8">No</th>
                            <th className="p-2 border-r border-black">Tujuan Pembelajaran (TP)</th>
                            <th className="p-2 border-r border-black">Materi Pokok</th>
                            <th className="p-2 border-r border-black">Profil Pelajar Pancasila &amp; KBC</th>
                            <th className="p-2 text-center w-14">JP</th>
                          </tr>
                        </thead>
                        <tbody>
                          {printDoc.contentData.alurTujuanPembelajaran.map((atp, idx) => (
                            <tr key={idx} className="border-b border-black">
                              <td className="p-2 border-r border-black text-center">{atp.no || idx + 1}</td>
                              <td className="p-2 border-r border-black">{atp.tujuan}</td>
                              <td className="p-2 border-r border-black">{atp.materi}</td>
                              <td className="p-2 border-r border-black">{atp.profilPancasilaKBC}</td>
                              <td className="p-2 text-center font-bold">{atp.alokasiJP} JP</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </>
              )}

              {/* PROTA */}
              {printDoc.docType === 'prota' && printDoc.contentData.protaItems && (
                <div className="space-y-3">
                  <table className="w-full text-left border border-black border-collapse">
                    <thead>
                      <tr className="bg-slate-100 border-b border-black font-bold">
                        <th className="p-2 border-r border-black text-center w-8">No</th>
                        <th className="p-2 border-r border-black w-20">Semester</th>
                        <th className="p-2 border-r border-black">Materi Pokok / Bab</th>
                        <th className="p-2 border-r border-black">Tujuan Pembelajaran</th>
                        <th className="p-2 border-r border-black text-center w-14">JP</th>
                        <th className="p-2 w-28">Keterangan</th>
                      </tr>
                    </thead>
                    <tbody>
                      {printDoc.contentData.protaItems.map((item, idx) => (
                        <tr key={idx} className="border-b border-black">
                          <td className="p-2 border-r border-black text-center">{item.no}</td>
                          <td className="p-2 border-r border-black font-bold">{item.semester}</td>
                          <td className="p-2 border-r border-black font-semibold">{item.materiPokok}</td>
                          <td className="p-2 border-r border-black">{item.tujuanPembelajaran}</td>
                          <td className="p-2 border-r border-black text-center font-bold">{item.alokasiJP} JP</td>
                          <td className="p-2 text-[10px] text-slate-700">{item.keterangan || '-'}</td>
                        </tr>
                      ))}
                      <tr className="bg-slate-50 font-bold border-t-2 border-black">
                        <td colSpan={4} className="p-2 text-right border-r border-black">
                          TOTAL ALOKASI WAKTU 1 TAHUN AJARAN:
                        </td>
                        <td className="p-2 text-center border-r border-black">
                          {printDoc.contentData.totalJPTahunan || 108} JP
                        </td>
                        <td className="p-2">Tuntas</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}

              {/* PROMES */}
              {printDoc.docType === 'promes' && printDoc.contentData.promesItems && (
                <div className="space-y-3">
                  <table className="w-full text-left border border-black border-collapse">
                    <thead>
                      <tr className="bg-slate-100 border-b border-black font-bold">
                        <th className="p-2 border-r border-black text-center w-8">No</th>
                        <th className="p-2 border-r border-black">Materi Pokok / Sub-Bab</th>
                        <th className="p-2 border-r border-black">Tujuan Pembelajaran</th>
                        <th className="p-2 border-r border-black text-center w-14">JP</th>
                        <th className="p-2">Distribusi Pekan Efektif</th>
                      </tr>
                    </thead>
                    <tbody>
                      {printDoc.contentData.promesItems.map((item, idx) => (
                        <tr key={idx} className="border-b border-black">
                          <td className="p-2 border-r border-black text-center">{item.no}</td>
                          <td className="p-2 border-r border-black font-bold">{item.materiPokok}</td>
                          <td className="p-2 border-r border-black">{item.tujuanPembelajaran}</td>
                          <td className="p-2 border-r border-black text-center font-bold">{item.alokasiJP} JP</td>
                          <td className="p-2">
                            {item.distribusiBulan.map(b => `${b.bulan} (${b.minggu.filter(m => m > 0).join(', ')} JP)`).join('; ')}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* KKTP */}
              {printDoc.docType === 'kktp' && printDoc.contentData.kktpItems && (
                <div className="space-y-4">
                  {printDoc.contentData.kktpItems.map((kktp, idx) => (
                    <div key={idx} className="border border-black p-3 space-y-2">
                      <div className="font-bold text-sm">
                        {kktp.no}. {kktp.tujuanPembelajaran}
                      </div>
                      <p><b>Indikator Ketercapaian:</b> {kktp.indikatorKetuntasan}</p>
                      
                      <table className="w-full border border-black border-collapse mt-2 text-[11px]">
                        <thead>
                          <tr className="bg-slate-100 border-b border-black font-bold">
                            <th className="p-1.5 border-r border-black w-1/4">Perlu Bimbingan (0-60)</th>
                            <th className="p-1.5 border-r border-black w-1/4">Cukup (61-75)</th>
                            <th className="p-1.5 border-r border-black w-1/4">Baik (76-88)</th>
                            <th className="p-1.5 w-1/4">Sangat Baik (89-100)</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td className="p-1.5 border-r border-black align-top">{kktp.kriteria.perluBimbingan}</td>
                            <td className="p-1.5 border-r border-black align-top">{kktp.kriteria.cukup}</td>
                            <td className="p-1.5 border-r border-black align-top">{kktp.kriteria.baik}</td>
                            <td className="p-1.5 align-top font-medium">{kktp.kriteria.sangatBaik}</td>
                          </tr>
                        </tbody>
                      </table>

                      <div className="text-[11px] bg-slate-50 p-2 border border-black/30 mt-1">
                        <b>Intervensi Pendekatan Kasih Sayang (KBC):</b> {kktp.tindakLanjutKBC}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* MODUL AJAR (RPP LENGKAP) */}
              {printDoc.docType === 'modul_ajar' && printDoc.contentData.modulAjar && (
                <div className="space-y-4 text-justify">
                  <div className="space-y-1">
                    <h5 className="font-bold text-sm uppercase">I. INFORMASI UMUM</h5>
                    <table className="w-full border border-black border-collapse text-xs">
                      <tbody>
                        <tr className="border-b border-black">
                          <td className="p-1.5 font-bold w-44 bg-slate-50 border-r border-black">Kompetensi Awal</td>
                          <td className="p-1.5">{printDoc.contentData.modulAjar.kompetensiAwal}</td>
                        </tr>
                        <tr className="border-b border-black">
                          <td className="p-1.5 font-bold bg-slate-50 border-r border-black">Profil Pelajar Pancasila &amp; KBC</td>
                          <td className="p-1.5">{printDoc.contentData.modulAjar.profilPelajarPancasilaKBC.join(', ')}</td>
                        </tr>
                        <tr className="border-b border-black">
                          <td className="p-1.5 font-bold bg-slate-50 border-r border-black">Sarana &amp; Prasarana</td>
                          <td className="p-1.5">{printDoc.contentData.modulAjar.saranaPrasarana.join(', ')}</td>
                        </tr>
                        <tr>
                          <td className="p-1.5 font-bold bg-slate-50 border-r border-black">Model Pembelajaran</td>
                          <td className="p-1.5">{printDoc.contentData.modulAjar.modelPembelajaran}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <div className="space-y-1.5">
                    <h5 className="font-bold text-sm uppercase">II. KOMPONEN INTI</h5>
                    <p><b>1. Tujuan Pembelajaran:</b></p>
                    <ul className="list-disc pl-5">
                      {printDoc.contentData.modulAjar.komponenInti.tujuanPembelajaran.map((tp, idx) => (
                        <li key={idx}>{tp}</li>
                      ))}
                    </ul>

                    <p className="mt-2"><b>2. Pemahaman Bermakna (Kurikulum Berbasis Cinta):</b></p>
                    <p className="pl-3 border-l-2 border-black italic">
                      "{printDoc.contentData.modulAjar.komponenInti.pemahamanBermakna}"
                    </p>

                    <p className="mt-2"><b>3. Pertanyaan Pemantik:</b></p>
                    <ul className="list-disc pl-5">
                      {printDoc.contentData.modulAjar.komponenInti.pertanyaanPemantik.map((q, idx) => (
                        <li key={idx}>{q}</li>
                      ))}
                    </ul>

                    <p className="mt-2 font-bold">4. Langkah-Langkah Kegiatan Pembelajaran:</p>
                    <div className="space-y-2 border border-black p-3 rounded">
                      <div>
                        <b>A. Pendahuluan:</b>
                        <ul className="list-disc pl-5">
                          {printDoc.contentData.modulAjar.komponenInti.kegiatanPembelajaran.pendahuluan.map((act, i) => (
                            <li key={i}>{act}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <b>B. Kegiatan Inti:</b>
                        <ul className="list-disc pl-5">
                          {printDoc.contentData.modulAjar.komponenInti.kegiatanPembelajaran.kegiatanInti.map((act, i) => (
                            <li key={i}>{act}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <b>C. Kegiatan Penutup:</b>
                        <ul className="list-disc pl-5">
                          {printDoc.contentData.modulAjar.komponenInti.kegiatanPembelajaran.penutup.map((act, i) => (
                            <li key={i}>{act}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <p className="mt-2 font-bold">5. Asesmen:</p>
                    <p>&bull; <b>Diagnostik:</b> {printDoc.contentData.modulAjar.komponenInti.asesmen.diagnostik}</p>
                    <p>&bull; <b>Formatif:</b> {printDoc.contentData.modulAjar.komponenInti.asesmen.formatif}</p>
                    <p>&bull; <b>Sumatif:</b> {printDoc.contentData.modulAjar.komponenInti.asesmen.sumatif}</p>
                  </div>
                </div>
              )}

              {/* LKPD */}
              {printDoc.docType === 'lkpd' && printDoc.contentData.lkpd && (
                <div className="space-y-4">
                  {/* Kolom Nama & Identitas Siswa */}
                  <div className="border border-black p-3 rounded flex justify-between text-xs">
                    <div>
                      <p><b>Nama Siswa :</b> ..............................................................</p>
                      <p className="mt-1"><b>Kelas :</b> {printDoc.classGrade} (SDN Ciketing Udik 2)</p>
                    </div>
                    <div>
                      <p><b>No. Absen :</b> ................</p>
                      <p className="mt-1"><b>Hari/Tgl :</b> ....................................</p>
                    </div>
                  </div>

                  <div className="border-l-4 border-black pl-3 py-1">
                    <h4 className="font-bold text-sm uppercase">{printDoc.contentData.lkpd.judulAktivitas}</h4>
                    <p className="italic text-slate-700">Tema Nilai Kasih Sayang: {printDoc.contentData.lkpd.temaNilaiKBC}</p>
                  </div>

                  {printDoc.contentData.lkpd.stimulusCerita && (
                    <div className="border border-black p-3 bg-slate-50 text-justify">
                      <b>Kisah Inspiratif Sahabat Sekolah:</b>
                      <p className="mt-1 italic">{printDoc.contentData.lkpd.stimulusCerita}</p>
                    </div>
                  )}

                  {printDoc.contentData.lkpd.arabicSnippet && (
                    <div className="border border-black p-3 text-center my-3 bg-slate-50">
                      <p className="font-serif text-lg leading-loose" dir="rtl">
                        {printDoc.contentData.lkpd.arabicSnippet.text}
                      </p>
                      <p className="text-[11px] italic mt-1">"{printDoc.contentData.lkpd.arabicSnippet.arti}"</p>
                    </div>
                  )}

                  <div className="space-y-2 mt-4">
                    <h5 className="font-bold text-sm uppercase">Lembar Jawaban Siswa:</h5>
                    {printDoc.contentData.lkpd.tugasSiswa.map((t, idx) => (
                      <div key={idx} className="border border-black p-3 space-y-2">
                        <div className="font-bold">{t.nomor}. {t.instruksi}</div>
                        {t.opsi && (
                          <div className="pl-4 space-y-1">
                            {t.opsi.map((op, oi) => (
                              <div key={oi}>({String.fromCharCode(65 + oi)}) {op}</div>
                            ))}
                          </div>
                        )}
                        <div className="pt-2">
                          <p className="text-[11px] text-slate-500">Tuliskan jawabanmu di sini:</p>
                          <div className="border-b border-dotted border-black h-8" />
                          <div className="border-b border-dotted border-black h-8" />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="border border-black p-3 bg-slate-50 mt-4">
                    <b>Refleksi Kalbu (Kurikulum Berbasis Cinta):</b>
                    <p className="italic mt-1">{printDoc.contentData.lkpd.refleksiCinta}</p>
                    <div className="border-b border-dotted border-black h-8 mt-2" />
                  </div>
                </div>
              )}

              {/* DOKUMEN LAINNYA IN PRINT PREVIEW */}
              {printDoc.docType === 'lainnya' && printDoc.contentData.dokumenLainnya && (
                <div className="space-y-4">
                  <div className="border border-black p-3 bg-slate-50">
                    <p><b>Kategori Perangkat Ajar:</b> {printDoc.contentData.dokumenLainnya.subKategori}</p>
                    {printDoc.contentData.dokumenLainnya.tujuanDokumen && (
                      <p className="mt-1"><b>Tujuan / Sasaran:</b> {printDoc.contentData.dokumenLainnya.tujuanDokumen}</p>
                    )}
                  </div>

                  {printDoc.contentData.dokumenLainnya.uraianIsi && (
                    <div className="border border-black p-3 whitespace-pre-line text-justify">
                      <h5 className="font-bold text-sm uppercase mb-1">Uraian Isi Perangkat Ajar:</h5>
                      {printDoc.contentData.dokumenLainnya.uraianIsi}
                    </div>
                  )}

                  {printDoc.contentData.dokumenLainnya.tabelBaris &&
                    printDoc.contentData.dokumenLainnya.tabelBaris.length > 0 && (
                      <table className="w-full text-left border border-black border-collapse">
                        <thead>
                          <tr className="bg-slate-100 border-b border-black font-bold">
                            <th className="p-2 border-r border-black text-center w-8">No</th>
                            <th className="p-2 border-r border-black w-1/3">Aspek / Komponen</th>
                            <th className="p-2 border-r border-black">Uraian / Indikator</th>
                            <th className="p-2 text-center w-24">Keterangan</th>
                          </tr>
                        </thead>
                        <tbody>
                          {printDoc.contentData.dokumenLainnya.tabelBaris.map((row, idx) => (
                            <tr key={idx} className="border-b border-black">
                              <td className="p-2 border-r border-black text-center">{row.no || idx + 1}</td>
                              <td className="p-2 border-r border-black font-bold">{row.aspek}</td>
                              <td className="p-2 border-r border-black">{row.uraian}</td>
                              <td className="p-2 text-center font-semibold">{row.keterangan}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                </div>
              )}
            </div>

            {/* DUAL SIGNATURE BLOCK (RESMI KEPALA SEKOLAH & GURU PAI) */}
            <div className="mt-12 pt-6 border-t border-black/40 flex justify-between text-xs">
              <div className="text-center w-64">
                <p>Mengetahui,</p>
                <p className="font-bold">Kepala Sekolah</p>
                <div className="h-20" />
                <p className="font-bold underline uppercase">{printDoc.principalName || appSettings.principalName || 'Hj. Siti Aminah, M.Pd'}</p>
                <p>NIP. {printDoc.principalNip || appSettings.principalNip || '197608201999032001'}</p>
              </div>

              <div className="text-center w-64">
                <p>Bekasi, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                <p className="font-bold">Guru Pendidikan Agama Islam &amp; BP</p>
                <div className="h-20" />
                <p className="font-bold underline uppercase">{printDoc.teacherName || teacherProfile.fullName || 'H. Ahmad Syarif, S.Pd.I'}</p>
                <p>NIP. {printDoc.teacherNip || teacherProfile.nip || '198503152010011002'}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MANUAL INPUT / EDIT MODAL */}
      <ManualTeachingDocModal
        isOpen={isManualModalOpen}
        onClose={() => {
          setIsManualModalOpen(false);
          setEditingDoc(null);
          setActiveManualRefDoc(null);
          refreshReferenceDocs();
        }}
        onSave={handleSaveManualDocument}
        editingDoc={editingDoc}
        defaultGrade={selectedGrade}
        defaultDocType={manualDefaultType}
        initialReferenceDoc={activeManualRefDoc}
        appSettings={appSettings}
        teacherProfile={teacherProfile}
        showToast={showToast}
      />

      {/* UPLOAD & LIBRARY DOKUMEN ACUAN / SANDARAN MODAL */}
      <UploadReferenceDocModal
        isOpen={isUploadRefModalOpen}
        onClose={() => {
          setIsUploadRefModalOpen(false);
          refreshReferenceDocs();
        }}
        defaultGrade={selectedGrade}
        defaultDocType={selectedDocType !== 'all' ? selectedDocType : 'cp_atp'}
        appSettings={appSettings}
        teacherProfile={teacherProfile}
        showToast={showToast}
        onRefreshDocs={refreshReferenceDocs}
        onUseAsManualReference={(refDoc) => {
          refreshReferenceDocs();
          openManualInputModal(refDoc.docType, refDoc);
        }}
        onUseAsAiReference={(refDoc) => {
          refreshReferenceDocs();
          setSelectedAiRefId(refDoc.id);
          setAiDocType(refDoc.docType);
          setAiGrade(refDoc.classGrade !== 'all' ? refDoc.classGrade : '5');
          setAiPreviewDoc(null);
          setIsAiModalOpen(true);
        }}
      />

      {/* DELETE CONFIRMATION MODAL */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="glass-strong border border-rose-500/30 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30 shadow-lg shadow-rose-500/10">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white text-center font-display">
              Hapus Perangkat Ajar?
            </h3>
            <p className="text-xs text-slate-300 text-center mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus dokumen{' '}
              <span className="text-white font-bold">"{deleteTarget.title}"</span>? Tindakan ini tidak dapat dibatalkan.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" /> Ya, Hapus Sekarang
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
