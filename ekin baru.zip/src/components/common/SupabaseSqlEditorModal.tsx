import React, { useState, useEffect } from 'react';
import {
  Database,
  Copy,
  CheckCircle2,
  Download,
  ExternalLink,
  RefreshCw,
  Terminal,
  Sparkles,
  AlertTriangle,
  Trash2,
  Cloud,
  X
} from 'lucide-react';
import { SupabaseService } from '../../services/supabaseService';
import { StorageService, STORAGE_KEYS } from '../../services/storageService';

interface SupabaseSqlEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  showToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onDataCleaned?: () => void;
}

type SqlTabType = 'setup_cloud_store' | 'relational_schema' | 'clean_demo' | 'insert_snapshot';

export const SupabaseSqlEditorModal: React.FC<SupabaseSqlEditorModalProps> = ({
  isOpen,
  onClose,
  showToast,
  onDataCleaned
}) => {
  const [activeTab, setActiveTab] = useState<SqlTabType>('setup_cloud_store');
  const [sqlContent, setSqlContent] = useState<string>(() => SupabaseService.getSqlSetupScript());
  const [copied, setCopied] = useState(false);
  const [isInspecting, setIsInspecting] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isCleaningDemo, setIsCleaningDemo] = useState(false);
  const [inspectResult, setInspectResult] = useState<{
    supabaseConnected: boolean;
    supabaseTableReady: boolean;
    supabaseError?: string;
    supabaseRowCount: number;
    serverStoreRowCount: number;
    rowsSummary: Array<{ key: string; itemCount: string; updatedAt: string; source: string }>;
  } | null>(null);

  const notify = (msg: string, type: 'success' | 'error' | 'info' = 'success') => {
    if (showToast) showToast(msg, type);
  };

  const getProjectRef = () => {
    const cfg = SupabaseService.getConfig();
    const url = cfg.url;
    if (!url) return '';
    const match = url.match(/https?:\/\/([^.]+)\.supabase\.co/i);
    return match ? match[1] : '';
  };

  const loadTabScript = (tab: SqlTabType) => {
    setActiveTab(tab);
    if (tab === 'setup_cloud_store') {
      setSqlContent(SupabaseService.getSqlSetupScript());
    } else if (tab === 'relational_schema') {
      setSqlContent(SupabaseService.getRelationalTablesSqlScript());
    } else if (tab === 'clean_demo') {
      setSqlContent(SupabaseService.getCleanDemoDataSqlScript());
    } else if (tab === 'insert_snapshot') {
      const allKeys = Object.values(STORAGE_KEYS).filter(k => k !== STORAGE_KEYS.SESSION);
      setSqlContent(SupabaseService.generateInsertCurrentDataSqlScript(allKeys));
    }
  };

  const handleInspectStatus = async () => {
    setIsInspecting(true);
    try {
      const res = await SupabaseService.inspectCloudStoreStatus();
      setInspectResult(res);
    } finally {
      setIsInspecting(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadTabScript(activeTab);
      handleInspectStatus();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCopySql = () => {
    navigator.clipboard.writeText(sqlContent);
    setCopied(true);
    notify('Skrip SQL berhasil disalin ke clipboard! Silakan tempel (Paste) di SQL Editor Supabase.', 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadSql = () => {
    const blob = new Blob([sqlContent], { type: 'text/sql;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `supabase_${activeTab}_${new Date().toISOString().split('T')[0]}.sql`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    notify('File skrip .sql berhasil diunduh!', 'success');
  };

  const handleCleanDemoData = async () => {
    setIsCleaningDemo(true);
    try {
      const res = await StorageService.cleanDemoDataKeepRealData();
      await handleInspectStatus();
      if (activeTab === 'insert_snapshot') {
        const allKeys = Object.values(STORAGE_KEYS).filter(k => k !== STORAGE_KEYS.SESSION);
        setSqlContent(SupabaseService.generateInsertCurrentDataSqlScript(allKeys));
      }
      if (onDataCleaned) onDataCleaned();
      notify(res.message, 'success');
    } finally {
      setIsCleaningDemo(false);
    }
  };

  const handleSyncToSupabase = async () => {
    setIsSyncing(true);
    try {
      await StorageService.flushOfflineQueue();
      const res = await StorageService.syncAllToSupabase();
      await StorageService.pullAllFromSupabase();
      await handleInspectStatus();
      if (onDataCleaned) onDataCleaned();
      notify(res.message, 'success');
    } finally {
      setIsSyncing(false);
    }
  };

  const projectRef = getProjectRef();
  const supabaseDashboardSqlUrl = `https://supabase.com/dashboard/project/${projectRef}/sql/new`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/85 backdrop-blur-md">
      <div className="glass-strong rounded-3xl w-full max-w-5xl max-h-[92vh] flex flex-col border border-cyan-500/35 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-cyan-950/60 to-emerald-950/60 border-b border-white/10 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-cyan-500 to-emerald-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20 shrink-0">
              <Terminal className="w-6 h-6" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold font-display text-white">
                  SQL Editor &amp; Konfigurasi Tabel Database Supabase
                </h3>
                <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-400/30 text-cyan-300 text-[10px] font-bold font-mono">
                  Project: {projectRef}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Salin dan jalankan skrip SQL di bawah pada <b>SQL Editor Supabase</b> agar tabel penyimpanan lintas perangkat aktif sepenuhnya.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 scrollbar-thin flex-1">
          {/* Live Connection & Table Status Bar */}
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/10 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            <div className="flex items-start sm:items-center gap-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  inspectResult?.supabaseTableReady
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}
              >
                {inspectResult?.supabaseTableReady ? (
                  <CheckCircle2 className="w-5 h-5" />
                ) : (
                  <AlertTriangle className="w-5 h-5" />
                )}
              </div>
              <div className="text-xs space-y-0.5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-bold text-white">Status Tabel Supabase (`public.lms_cloud_store`):</span>
                  {isInspecting ? (
                    <span className="text-cyan-300 font-bold">Memeriksa koneksi...</span>
                  ) : inspectResult?.supabaseTableReady ? (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                      ● Aktif &amp; Siap ({inspectResult.supabaseRowCount} Koleksi di Supabase)
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                      ● Tabel SQL Belum Dibuat di Supabase (Aktif di Server Cloud: {inspectResult?.serverStoreRowCount || 0} Koleksi)
                    </span>
                  )}
                </div>
                {inspectResult?.supabaseError && !inspectResult.supabaseTableReady ? (
                  <p className="text-[11px] text-amber-200/90">
                    Info Supabase: <code className="font-mono">{inspectResult.supabaseError}</code> — Silakan salin <b>Skrip 1</b> di bawah lalu klik <b>Run</b> di SQL Editor Supabase.
                  </p>
                ) : (
                  <p className="text-[11px] text-slate-400">
                    Seluruh perubahan data otomatis disinkronkan ke tabel <code className="text-cyan-300">public.lms_cloud_store</code> dan Server Cloud Store.
                  </p>
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleCleanDemoData}
                disabled={isCleaningDemo}
                className="px-3.5 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/35 text-amber-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <Trash2 className="w-3.5 h-3.5 text-amber-300" />
                {isCleaningDemo ? 'Membersihkan...' : 'Bersihkan Sisa Data Demo'}
              </button>

              <button
                type="button"
                onClick={handleSyncToSupabase}
                disabled={isSyncing}
                className="px-3.5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <Cloud className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                {isSyncing ? 'Menyinkronkan...' : 'Sinkronkan ke Supabase'}
              </button>

              <button
                type="button"
                onClick={handleInspectStatus}
                disabled={isInspecting}
                className="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isInspecting ? 'animate-spin' : ''}`} />
                Cek Status
              </button>
            </div>
          </div>

          {/* 4 SQL Script Preset Tabs */}
          <div className="flex flex-wrap items-center gap-2 border-b border-white/10 pb-3">
            <button
              type="button"
              onClick={() => loadTabScript('setup_cloud_store')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                activeTab === 'setup_cloud_store'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              1. Skrip Utama `lms_cloud_store` (Wajib)
            </button>

            <button
              type="button"
              onClick={() => loadTabScript('relational_schema')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                activeTab === 'relational_schema'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              2. Skema Tabel Relasional Lengkap (8 Tabel)
            </button>

            <button
              type="button"
              onClick={() => loadTabScript('clean_demo')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                activeTab === 'clean_demo'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
              }`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              3. SQL Reset Nilai / Kosongkan Demo
            </button>

            <button
              type="button"
              onClick={() => loadTabScript('insert_snapshot')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                activeTab === 'insert_snapshot'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              4. Generate SQL `INSERT` Data Saat Ini
            </button>
          </div>

          {/* Interactive SQL Editor Box */}
          <div className="rounded-2xl bg-slate-950 border border-cyan-500/30 overflow-hidden shadow-inner">
            <div className="px-4 py-2.5 bg-slate-900/90 border-b border-white/10 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <span className="text-xs font-mono font-bold text-cyan-300 ml-1">
                  postgresql://supabase/{projectRef}/sql_editor.sql
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopySql}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 cursor-pointer transition-all shadow-md"
                >
                  {copied ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" /> Tersalin!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" /> Salin Skrip SQL
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleDownloadSql}
                  className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-cyan-300" /> Unduh .SQL
                </button>

                <a
                  href={supabaseDashboardSqlUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" /> Buka SQL Editor Supabase
                </a>
              </div>
            </div>

            <textarea
              value={sqlContent}
              onChange={e => setSqlContent(e.target.value)}
              rows={15}
              spellCheck={false}
              className="w-full p-4 bg-slate-950 text-emerald-300 font-mono text-xs leading-relaxed focus:outline-none resize-y scrollbar-thin"
            />
          </div>

          {/* Step-by-step Guide + Current Cloud Table Contents */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            <div className="lg:col-span-5 p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5 text-xs">
              <h4 className="font-bold text-cyan-300 uppercase tracking-wider text-[11px]">
                Panduan 3 Langkah Menjalankan di Supabase:
              </h4>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-300 leading-relaxed">
                <li>
                  Klik tombol <b>&ldquo;Salin Skrip SQL&rdquo;</b> berwarna hijau di atas.
                </li>
                <li>
                  Klik <b>&ldquo;Buka SQL Editor Supabase&rdquo;</b>, tempel (<i>Paste</i>) skrip pada lembar query baru, lalu klik tombol <b>RUN</b>.
                </li>
                <li>
                  Kembali ke halaman ini lalu klik <b>&ldquo;Sinkronkan ke Supabase&rdquo;</b> agar seluruh data asli Anda tersimpan di tabel Supabase.
                </li>
              </ol>
            </div>

            <div className="lg:col-span-7 p-4 rounded-2xl bg-slate-900/70 border border-white/10 space-y-2.5">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-emerald-300 uppercase tracking-wider text-[11px]">
                  Daftar Koleksi Data yang Tersimpan di Cloud Saat Ini ({inspectResult?.rowsSummary.length || 0} Koleksi)
                </h4>
                <span className="text-[10px] text-slate-400">Real-time Inspector</span>
              </div>

              <div className="max-h-40 overflow-y-auto scrollbar-thin border border-white/10 rounded-xl">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-slate-950 text-slate-400 sticky top-0">
                    <tr>
                      <th className="py-2 px-3 font-bold">Kunci Tabel (`store_key`)</th>
                      <th className="py-2 px-3 font-bold">Isi Data</th>
                      <th className="py-2 px-3 font-bold">Sumber</th>
                      <th className="py-2 px-3 font-bold">Update Terakhir</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-200">
                    {inspectResult?.rowsSummary.length ? (
                      inspectResult.rowsSummary.map(row => (
                        <tr key={row.key} className="hover:bg-white/5">
                          <td className="py-1.5 px-3 font-mono text-cyan-300">{row.key}</td>
                          <td className="py-1.5 px-3 font-bold text-emerald-300">{row.itemCount}</td>
                          <td className="py-1.5 px-3 text-slate-300">{row.source}</td>
                          <td className="py-1.5 px-3 font-mono text-slate-400">
                            {row.updatedAt
                              ? new Date(row.updatedAt).toLocaleString('id-ID')
                              : '-'}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={4} className="py-4 text-center text-slate-400">
                          Belum ada koleksi data yang tercatat.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900/90 border-t border-white/10 flex items-center justify-between">
          <span className="text-[11px] text-slate-400">
            Endpoint Aktif: <code className="text-cyan-300 font-mono">{SupabaseService.getConfig().url}</code>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold cursor-pointer"
          >
            Tutup SQL Editor
          </button>
        </div>
      </div>
    </div>
  );
};
